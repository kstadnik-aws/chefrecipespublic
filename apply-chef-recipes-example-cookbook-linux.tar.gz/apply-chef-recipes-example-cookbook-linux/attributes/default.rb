default['filepath'] = "/tmp/commitid.txt"
default['content']  = "COMMITID"