default['filepath'] = "/tmp/default.txt"
default['content']  = "default"