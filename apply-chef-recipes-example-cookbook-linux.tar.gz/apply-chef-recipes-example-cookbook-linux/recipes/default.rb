file node['filepath'] do
  content node['content']
  action :create
end