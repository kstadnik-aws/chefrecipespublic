AWS Systems Manager ApplyChefRecipes Example Cookbook
==============================

This cookbook is meant to provide a basic usage example of the AWS-ApplyChefRecipes document.